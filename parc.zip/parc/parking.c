#include "parking.h"

int places_libres = NB_PLACES_MAX;

