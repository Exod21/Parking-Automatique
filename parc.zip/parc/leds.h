#ifndef LEDS_H
#define LEDS_H

#include <stdbool.h>

void led_verte(bool on);
void led_rouge(bool on);

#endif
