#ifndef HISTORIQUE_H
#define HISTORIQUE_H

#include <stdint.h>

#define NB_HISTORIQUE 5

typedef struct
{
    uint8_t heure;
    uint8_t minute;
    char type[8];
} Evenement;

extern Evenement historique[NB_HISTORIQUE];
extern int nb_evenements;

void ajouter_evenement(const char *type);

#endif
