#ifndef AFFICHAGE_H
#define AFFICHAGE_H

void afficher_separateur(void);
void afficher_places(void);
void afficher_droite_complet(void);
void afficher_heure_seulement(void);
void afficher_interface(void);

#endif
