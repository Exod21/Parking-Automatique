#ifndef CAPTEURS_H
#define CAPTEURS_H

#include "stm32g4xx_hal.h"
#include <stdint.h>

#define TRIG_IN_PORT   GPIOA
#define TRIG_IN_PIN    GPIO_PIN_1

#define ECHO_IN_PORT   GPIOB
#define ECHO_IN_PIN    GPIO_PIN_4

#define TRIG_OUT_PORT  GPIOA
#define TRIG_OUT_PIN   GPIO_PIN_0

#define ECHO_OUT_PORT  GPIOB
#define ECHO_OUT_PIN   GPIO_PIN_5

uint32_t mesurer_distance(
        GPIO_TypeDef *t_port,
        uint16_t t_pin,
        GPIO_TypeDef *e_port,
        uint16_t e_pin);

#endif
