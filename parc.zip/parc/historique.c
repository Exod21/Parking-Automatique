#include "historique.h"
#include "rtc_manager.h"

#include <string.h>

Evenement historique[NB_HISTORIQUE];
int nb_evenements = 0;

void ajouter_evenement(const char *type)
{
    uint8_t h, m, s;

    RTC_GetTime(&h, &m, &s);

    for (int i = NB_HISTORIQUE - 1; i > 0; i--)
    {
        historique[i] = historique[i - 1];
    }

    historique[0].heure = h;
    historique[0].minute = m;

    strncpy(historique[0].type, type,
            sizeof(historique[0].type) - 1);

    historique[0].type[sizeof(historique[0].type) - 1] = '\0';

    if (nb_evenements < NB_HISTORIQUE)
    {
        nb_evenements++;
    }
}
