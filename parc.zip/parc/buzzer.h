#ifndef BUZZER_H
#define BUZZER_H

void bip_aigu(void);
void bip_grave(void);
void bip_long_grave(void);
void bip_demarrage(void);

#endif
