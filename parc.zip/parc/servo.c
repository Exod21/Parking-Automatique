#include "servo.h"
#include "config.h"

TIM_HandleTypeDef htim2;

void Servo_Init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();

    htim2.Instance = TIM2;
    htim2.Init.Prescaler = 64 - 1;
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = 20000 - 1;
    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;

    HAL_TIM_PWM_Init(&htim2);

    TIM_OC_InitTypeDef sConfig = {0};

    sConfig.OCMode = TIM_OCMODE_PWM1;
    sConfig.Pulse = 1000;
    sConfig.OCPolarity = TIM_OCPOLARITY_HIGH;

    HAL_TIM_PWM_ConfigChannel(&htim2,
                              &sConfig,
                              TIM_CHANNEL_3);

    HAL_TIM_PWM_Start(&htim2,
                      TIM_CHANNEL_3);
}

void Servo_SetAngle(uint8_t angle)
{
    uint16_t pulse = 1000 + (angle * 1000) / 180;

    __HAL_TIM_SET_COMPARE(
        &htim2,
        TIM_CHANNEL_3,
        pulse
    );
}

void barriere_ouvrir(void)
{
    for (int angle = 0; angle <= 220; angle += 2)
    {
        Servo_SetAngle(angle);
        HAL_Delay(20);
    }
}

void barriere_fermer(void)
{
    for (int angle = 220; angle >= 0; angle -= 2)
    {
        Servo_SetAngle(angle);
        HAL_Delay(20);
    }
}

