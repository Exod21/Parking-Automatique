#include "leds.h"
#include "config.h"

#include "stm32g4xx_hal.h"

#define LED_VER_PORT GPIOB
#define LED_VER_PIN  GPIO_PIN_0

#define LED_ROU_PORT GPIOB
#define LED_ROU_PIN  GPIO_PIN_6

void led_verte(bool on)
{
    HAL_GPIO_WritePin(
        LED_VER_PORT,
        LED_VER_PIN,
        on ? GPIO_PIN_SET : GPIO_PIN_RESET
    );
}

void led_rouge(bool on)
{
    HAL_GPIO_WritePin(
        LED_ROU_PORT,
        LED_ROU_PIN,
        on ? GPIO_PIN_SET : GPIO_PIN_RESET
    );
}

