#ifndef GPIO_INIT_H
#define GPIO_INIT_H

void init_GPIO(void);

#endif
