#ifndef PARKING_H
#define PARKING_H

#define NB_PLACES_MAX 3
#define SEUIL_CM 20

extern int places_libres;

#endif
