#include "config.h"

#include "parking.h"
#include "rtc_manager.h"
#include "historique.h"
#include "leds.h"
#include "buzzer.h"
#include "servo.h"
#include "capteurs.h"
#include "affichage.h"
#include "gpio_init.h"

#include "stm32g4_sys.h"
#include "stm32g4_gpio.h"
#include "stm32g4_uart.h"
#include "stm32g4_utils.h"

#include "tft_ili9341/stm32g4_ili9341.h"

#include <stdio.h>
#include <stdbool.h>

int main(void)
{
    HAL_Init();

    BSP_GPIO_enable();

    BSP_UART_init(UART2_ID, 115200);
    BSP_SYS_set_std_usart(UART2_ID, UART2_ID, UART2_ID);

    init_GPIO();

    RTC_Init();

    ILI9341_Init();

    Servo_Init();

    barriere_fermer();

    afficher_interface();

    bip_demarrage();

    bool entree_block = false;
    bool sortie_block = false;

    uint32_t last_heure = 0;

    while (1)
    {
        uint32_t dist_in = mesurer_distance(
                TRIG_IN_PORT,
                TRIG_IN_PIN,
                ECHO_IN_PORT,
                ECHO_IN_PIN);

        uint32_t dist_out = mesurer_distance(
                TRIG_OUT_PORT,
                TRIG_OUT_PIN,
                ECHO_OUT_PORT,
                ECHO_OUT_PIN);

        /* Debug UART */
        static uint32_t last_uart = 0;

        if (HAL_GetTick() - last_uart > 500)
        {
            uint8_t h, m, s;

            RTC_GetTime(&h, &m, &s);

            printf("[%02d:%02d:%02d] E:%4ld mm  S:%4ld mm  Places:%d/%d\r\n",
                   h,
                   m,
                   s,
                   dist_in,
                   dist_out,
                   places_libres,
                   NB_PLACES_MAX);

            last_uart = HAL_GetTick();
        }

        /* Rafraîchissement heure */
        if (HAL_GetTick() - last_heure > 1000)
        {
            afficher_heure_seulement();
            afficher_separateur();

            last_heure = HAL_GetTick();
        }

        /* Entrée véhicule */
        if (dist_in < (SEUIL_CM * 10) && !entree_block)
        {
            entree_block = true;

            if (places_libres > 0)
            {
                places_libres--;

                ajouter_evenement("ENTREE");

                led_verte(true);

                bip_aigu();

                barriere_ouvrir();

                HAL_Delay(2000);

                barriere_fermer();

                led_verte(false);
            }
            else
            {
                led_rouge(true);

                bip_long_grave();

                HAL_Delay(2000);

                led_rouge(false);
            }

            afficher_interface();

            HAL_Delay(500);

            entree_block = false;
        }

        /* Sortie véhicule */
        if (dist_out < (SEUIL_CM * 10)
            && !sortie_block
            && places_libres < NB_PLACES_MAX)
        {
            sortie_block = true;

            places_libres++;

            ajouter_evenement("SORTIE");

            bip_grave();

            led_verte(true);

            barriere_ouvrir();

            HAL_Delay(2000);

            barriere_fermer();

            led_verte(false);

            afficher_interface();

            sortie_block = false;
        }

        /* Parking complet */
        if (places_libres == 0)
        {
            led_rouge(true);
        }
        else
        {
            led_rouge(false);
        }

        HAL_Delay(50);
    }
}
