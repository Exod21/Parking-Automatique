#include "capteurs.h"

uint32_t mesurer_distance(GPIO_TypeDef *t_port,
                          uint16_t t_pin,
                          GPIO_TypeDef *e_port,
                          uint16_t e_pin)
{
    HAL_GPIO_WritePin(t_port, t_pin, GPIO_PIN_SET);

    for(int i = 0; i < 80; i++)
        __NOP();

    HAL_GPIO_WritePin(t_port, t_pin, GPIO_PIN_RESET);

    uint32_t timeout = 30000;
    uint32_t wait = 0;

    while(HAL_GPIO_ReadPin(e_port, e_pin) == GPIO_PIN_RESET
          && wait < timeout)
    {
        for(int i = 0; i < 10; i++)
            __NOP();

        wait++;
    }

    if(wait >= timeout)
        return 9999;

    uint32_t duree = 0;

    while(HAL_GPIO_ReadPin(e_port, e_pin) == GPIO_PIN_SET
          && duree < timeout)
    {
        for(int i = 0; i < 10; i++)
            __NOP();

        duree++;
    }

    if(duree >= timeout)
        return 9999;

    return (duree * 17) / 100;
}

