#ifndef SERVO_H
#define SERVO_H

#include "stm32g4xx_hal.h"
#include <stdint.h>

extern TIM_HandleTypeDef htim2;

void Servo_Init(void);
void Servo_SetAngle(uint8_t angle);

void barriere_ouvrir(void);
void barriere_fermer(void);

#endif
