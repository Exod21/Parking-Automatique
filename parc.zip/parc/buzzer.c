#include "buzzer.h"
#include "stm32g4xx_hal.h"

#define BUZZER_PORT GPIOA
#define BUZZER_PIN  GPIO_PIN_15

static void buzzer_on(void)
{
    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_SET);
}

static void buzzer_off(void)
{
    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_RESET);
}

// Son aigu (~1000 Hz)
void bip_aigu(void)
{
    for (int i = 0; i < 150; i++)
    {
        buzzer_on();
        HAL_Delay(1);

        buzzer_off();
        HAL_Delay(1);
    }
}

// Son grave (~250 Hz)
void bip_grave(void)
{
    for (int i = 0; i < 60; i++)
    {
        buzzer_on();
        HAL_Delay(2);

        buzzer_off();
        HAL_Delay(2);
    }
}

// Son grave long
void bip_long_grave(void)
{
    for (int i = 0; i < 120; i++)
    {
        buzzer_on();
        HAL_Delay(2);

        buzzer_off();
        HAL_Delay(2);
    }
}

// Double bip au démarrage
void bip_demarrage(void)
{
    bip_aigu();
    HAL_Delay(150);
    bip_aigu();
}
