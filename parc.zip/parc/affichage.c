#include "affichage.h"

#include "parking.h"
#include "historique.h"
#include "rtc_manager.h"

#include "tft_ili9341/stm32g4_ili9341.h"

#include <stdio.h>
#include <string.h>

void afficher_separateur(void) {
    for (int y = 0; y < 240; y++) {
        ILI9341_DrawPixel(160, y, ILI9341_COLOR_WHITE);
    }
}

// Zone gauche : places parking
void afficher_places(void) {
    char buf[32];

    // Titre
    ILI9341_Fill(ILI9341_COLOR_BLACK);
    ILI9341_Puts(18, 5,  "PARKING",    &Font_11x18, ILI9341_COLOR_CYAN,  ILI9341_COLOR_BLACK);
    ILI9341_Puts(5,  25, "-------------", &Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

    // Places
    ILI9341_Puts(10, 45, "[P1]", &Font_11x18, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
    ILI9341_Puts(10, 65, (places_libres < 3) ? "OCCUPE" : "LIBRE ", &Font_11x18,
                 (places_libres < 3) ? ILI9341_COLOR_RED : ILI9341_COLOR_GREEN, ILI9341_COLOR_BLACK);

    ILI9341_Puts(10, 95,  "[P2]", &Font_11x18, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
    ILI9341_Puts(10, 115, (places_libres < 2) ? "OCCUPE" : "LIBRE ", &Font_11x18,
                 (places_libres < 2) ? ILI9341_COLOR_RED : ILI9341_COLOR_GREEN, ILI9341_COLOR_BLACK);

    ILI9341_Puts(10, 145, "[P3]", &Font_11x18, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
    ILI9341_Puts(10, 165, (places_libres < 1) ? "OCCUPE" : "LIBRE ", &Font_11x18,
                 (places_libres < 1) ? ILI9341_COLOR_RED : ILI9341_COLOR_GREEN, ILI9341_COLOR_BLACK);

    // Résumé
    ILI9341_Puts(5, 195, "-------------", &Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);
    sprintf(buf, "%d/%d LIBRES", places_libres, NB_PLACES_MAX);
    ILI9341_Puts(10, 207, buf, &Font_11x18, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

    if (places_libres == 0)
        ILI9341_Puts(5, 225, "  COMPLET  ", &Font_7x10, ILI9341_COLOR_RED,   ILI9341_COLOR_BLACK);
    else
        ILI9341_Puts(5, 225, " DISPONIBLE", &Font_7x10, ILI9341_COLOR_GREEN, ILI9341_COLOR_BLACK);
}

// Zone droite : heure + historique
// Appelée UNE SEULE FOIS au démarrage et après chaque événement
void afficher_droite_complet(void) {
    // Effacer zone droite
    for (int y = 0; y < 240; y++)
        for (int x = 161; x < 320; x++)
            ILI9341_DrawPixel(x, y, ILI9341_COLOR_BLACK);

    // Titre heure
    ILI9341_Puts(168, 5, "HEURE", &Font_11x18, ILI9341_COLOR_CYAN, ILI9341_COLOR_BLACK);

    // Séparateur
    ILI9341_Puts(165, 50, "-----------", &Font_7x10, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK);

    // Titre historique
    ILI9341_Puts(165, 62, "HISTORIQUE", &Font_11x18, ILI9341_COLOR_CYAN, ILI9341_COLOR_BLACK);

    // Historique (ne change que lors d'un événement)
    for (int i = 0; i < nb_evenements; i++) {
        char buf[32];
        uint16_t couleur = (strncmp(historique[i].type, "ENTREE", 6) == 0)
                           ? ILI9341_COLOR_GREEN
                           : ILI9341_COLOR_RED;
        sprintf(buf, "%02d:%02d %s", historique[i].heure, historique[i].minute, historique[i].type);
        ILI9341_Puts(165, 85 + i * 28, buf, &Font_7x10, couleur, ILI9341_COLOR_BLACK);
    }
}

// Appelée chaque seconde – redessine UNIQUEMENT l'heure
void afficher_heure_seulement(void) {
    char buf[32];
    uint8_t h, m, s;
    RTC_GetTime(&h, &m, &s);

    // Effacer uniquement la zone de l'heure (ligne 25, hauteur 18px)
    for (int y = 25; y < 43; y++)
        for (int x = 165; x < 320; x++)
            ILI9341_DrawPixel(x, y, ILI9341_COLOR_BLACK);

    sprintf(buf, "%02d:%02d:%02d", h, m, s);
    ILI9341_Puts(165, 25, buf, &Font_11x18, ILI9341_COLOR_YELLOW, ILI9341_COLOR_BLACK);
}

// Rafraîchissement complet
void afficher_interface(void) {
    afficher_places();
    afficher_separateur();
    afficher_droite_complet();  // ← version complète
}

