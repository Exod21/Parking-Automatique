#include "gpio_init.h"

#include "capteurs.h"

#include "stm32g4_gpio.h"
#include "stm32g4xx_hal.h"

#define LED_VER_PORT GPIOB
#define LED_VER_PIN  GPIO_PIN_0

#define LED_ROU_PORT GPIOB
#define LED_ROU_PIN  GPIO_PIN_6

#define BUZZER_PORT GPIOA
#define BUZZER_PIN  GPIO_PIN_15

void init_GPIO(void)
{
    BSP_GPIO_pin_config(
        LED_VER_PORT,
        LED_VER_PIN,
        GPIO_MODE_OUTPUT_PP,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    BSP_GPIO_pin_config(
        LED_ROU_PORT,
        LED_ROU_PIN,
        GPIO_MODE_OUTPUT_PP,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    BSP_GPIO_pin_config(
        BUZZER_PORT,
        BUZZER_PIN,
        GPIO_MODE_OUTPUT_PP,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    BSP_GPIO_pin_config(
        TRIG_IN_PORT,
        TRIG_IN_PIN,
        GPIO_MODE_OUTPUT_PP,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    HAL_GPIO_WritePin(
        TRIG_IN_PORT,
        TRIG_IN_PIN,
        GPIO_PIN_RESET);

    BSP_GPIO_pin_config(
        ECHO_IN_PORT,
        ECHO_IN_PIN,
        GPIO_MODE_INPUT,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    BSP_GPIO_pin_config(
        TRIG_OUT_PORT,
        TRIG_OUT_PIN,
        GPIO_MODE_OUTPUT_PP,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    HAL_GPIO_WritePin(
        TRIG_OUT_PORT,
        TRIG_OUT_PIN,
        GPIO_PIN_RESET);

    BSP_GPIO_pin_config(
        ECHO_OUT_PORT,
        ECHO_OUT_PIN,
        GPIO_MODE_INPUT,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_LOW,
        GPIO_NO_AF);

    BSP_GPIO_pin_config(
        GPIOA,
        GPIO_PIN_2,
        GPIO_MODE_AF_PP,
        GPIO_NOPULL,
        GPIO_SPEED_FREQ_HIGH,
        GPIO_AF1_TIM2);
}

