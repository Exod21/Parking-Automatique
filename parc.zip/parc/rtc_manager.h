#ifndef RTC_MANAGER_H
#define RTC_MANAGER_H

#include "config.h"

extern RTC_HandleTypeDef hrtc;

void RTC_Init(void);
void RTC_GetTime(uint8_t *h, uint8_t *m, uint8_t *s);

#endif
